// Crie as variáveis com os tipos corretos

// String
let name = "ana";

// Number
let age = 16;

// Boolean
let isStudent = true;

// Exiba todas as variáveis
console.log(name);
console.log(age);
console.log(isStudent);