// Crie o array
let numeros = [1, 2, 3, 4, 5];

// Use loop for para percorrer
for (let i = 0; i < numeros.length; i++) {
    let resultado = numeros[i] * 2;
    console.log(resultado);
}