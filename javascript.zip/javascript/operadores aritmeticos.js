// Crie as variáveis
let a = 10;
let b = 5;

// Calcule e exiba os resultados
let soma = a + b;
let multiplicacao = a * b;
let divisao = a / b;

console.log("Soma:", soma);
console.log("Multiplicação:", multiplicacao);
console.log("Divisão:", divisao);