// Criação da função saudacao
function saudacao(nome) {
    return `Olá, ${nome}!`;
}

let resultado = saudacao("ana");
console.log(resultado);  