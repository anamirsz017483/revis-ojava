// Substitua ___ pelo seu código

// Crie a variável salary
let salary = 4950.5;

// Exiba a variável
console.log(salary);