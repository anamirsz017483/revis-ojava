// Crie a variável
let diaSemana = 3;

// Use switch case
switch (diaSemana) {
    case 1:
        console.log("Segunda-feira");
        break;
    case 2:
        console.log("Terça-feira");
        break;
    case 3:
        console.log("Quarta-feira");
        break;
    // Complete os outros casos
    default:
        console.log("Dia inválido");
}