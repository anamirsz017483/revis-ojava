// Crie o array de frutas
let frutas = ["uva", "banana", "maça"];

// Exiba o primeiro elemento
console.log("Primeira fruta:", frutas[0]);

// Exiba o tamanho
console.log("Tamanho:", frutas.length);

// Adicione uma fruta
frutas.push("manga");
console.log("Nova lista:", frutas);