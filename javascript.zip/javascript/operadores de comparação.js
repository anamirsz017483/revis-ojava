// Crie as variáveis
let x = 8;
let y = 12;

// Faça as comparações
let maiorQue = "x > y";
let igualA = "x === 8";
let diferenteDe = " y !== 10 ";

console.log("x > y:", maiorQue);
console.log("x === 8:", igualA);
console.log("y !== 10:", diferenteDe);