// Crie a variável nota
let nota = 85;

// Use if/else aninhados
if (nota >= 90) {
    console.log("Excelente");
} else if (nota >= 70) {
    console.log("Bom");
} else if (nota >= 50) {
    console.log("Regular");
} else {
    console.log("Insuficiente");
}