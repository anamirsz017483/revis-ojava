// Crie a variável
let idade = 18;

// Use if/else para verificar a idade
if (idade >= 18) {
    console.log("Maior de idade");
} else {
    console.log("Menor de idade");
}