// Crie a função calcularArea
function calcularArea(largura, altura) {
    return largura * altura;
}

// Teste a função
let area = calcularArea(5, 3);
console.log("Área:", area);