// Crie um loop for que conte de 1 até 5
for (let i = 1; i <= 5; i++) {
    console.log(i);
}
